package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hive3 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;
    private static ResultSet res=null;

    public static void main(String[]args)throws SQLException,
    ClassNotFoundException{
    	
    	Class.forName(driver);
        con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
        st=con.createStatement();
        
        
        
        String old ="select emp_id, first_name, bday from employee order by bday asc limit 10";
        res=st.executeQuery(old);
        while(res.next()){
        System.out.println(res.getString("emp_id")+" "+res.getString("first_name")+" "+res.getString("bday"));	
        }
        con.close();
    }

}
