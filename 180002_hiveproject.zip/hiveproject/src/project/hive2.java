package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class hive2 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;
   

    public static void main(String[]args)throws SQLException,
    ClassNotFoundException{
    	
    	Class.forName(driver);
        con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
        st=con.createStatement();
        
        //loading data in employee table 
        String ldemp= "load data local inpath '/home/cloudera/Downloads/employee.csv' overwrite into table employee";
        st.execute(ldemp);
        System.out.println("Employee data loaded");
        
        //loading data in salary table
        String ldsal= "load data local inpath '/home/cloudera/Downloads/salary.csv' overwrite into table salary";
        st.execute(ldsal);
        System.out.println("Salary data loaded");
        
    }

}
