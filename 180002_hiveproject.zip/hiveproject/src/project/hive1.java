package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hive1 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;
    private static ResultSet res=null;

    public static void main(String[]args)throws SQLException,
ClassNotFoundException{

    	// creation of tables
            Class.forName(driver);
            con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
            st=con.createStatement();
            st.execute("CREATE TABLE IF NOT EXISTS "
                    + "employee(emp_id int, bday String, first_name String,last_name String, gender varchar(100),work_day String) "
                    + "COMMENT 'EMP DETAILS' "
                    + "ROW FORMAT DELIMITED "
                    + "FIELDS TERMINATED BY ',' "
                    + "LINES TERMINATED BY '\n' "
                    + "STORED AS TEXTFILE");
            System.out.println("table is created");
            
            st.execute("CREATE TABLE IF NOT EXISTS "
                    + "salary(emp_id int, salary String, start_date String, end_date String) "
                    + "COMMENT 'EMP DETAILS' "
                    + "ROW FORMAT DELIMITED "
                    + "FIELDS TERMINATED BY ',' "
                    + "LINES TERMINATED BY '\n' "
                    + "STORED AS TEXTFILE");
            System.out.println("table is created");

            String database="show databases";
            res=st.executeQuery(database);
    while(res.next()){
       System.out.println(res.getString(1));
   }
   con.close();
    }

}
