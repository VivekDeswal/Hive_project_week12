package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hive4 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;
    private static ResultSet res=null;

    public static void main(String[]args)throws SQLException,
    ClassNotFoundException{
    	
    	Class.forName(driver);
        con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
        st=con.createStatement();
        
        // top 10 employees salary above than average highest salary
        
        String topavg="select e.first_name, e.last_name, avg(s.salary) as aver from employee as e join salary as s on (s.emp_id=e.emp_id) "
        		                                + "group by e.first_name, e.last_name order by aver desc limit 10";
         res=st.executeQuery(topavg);
         while(res.next()){
         System.out.println(res.getString("e.first_name")+"  "+res.getString("e.last_name")+"   "+res.getInt("aver"));	
        }
        con.close();
    }

}
