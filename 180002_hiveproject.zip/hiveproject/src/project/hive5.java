package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hive5 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;
    private static ResultSet res=null;

    public static void main(String[]args)throws SQLException,
    ClassNotFoundException{
    	
    	Class.forName(driver);
        con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
        st=con.createStatement();
        
        String tenslry ="select gender, count(gender) as count from employee group by gender";
        res=st.executeQuery(tenslry);
        while(res.next()){
        System.out.println(res.getString("gender")+" "+res.getString("count"));	
        }
        con.close();
    }

}
